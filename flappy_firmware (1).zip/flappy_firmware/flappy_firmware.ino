// Flappy Bird on an 8x8 LED matrix, driven by an ATtiny1616.
// Single button -- tap it to flap, don't hit a pipe.
//
// Hardware notes (from the schematic):
//   - Rows  -> PA0..PA7  (Row1..Row8) -- LED CATHODES (through 100R)
//   - Cols  -> PB0..PB5  (Col1..Col6)
//             PC0 -> Col7
//             PC1 -> Col8                -- LED ANODES (through 100R)
//   - PC2   -> SW_P1_UP, active low (one switch to GND, internal pull-up)
//
// Coordinate system used here:
//   x = column (0 .. 7), 0 is the bird's column on the left
//   y = row    (0 .. 7), 0 is the top
//
// Pipes scroll right-to-left. Each pipe has a "gap" -- the row range
// that's open. Hit a pipe column with your bird outside its gap and
// you die. Survive a pipe -> +1 score. Crash -> score blink, then
// press the button to play again.

#include <Arduino.h>

// ---------- pin map ----------
static const uint8_t ROW_PINS[8] = {
  PIN_PA0, PIN_PA1, PIN_PA2, PIN_PA3,
  PIN_PA4, PIN_PA5, PIN_PA6, PIN_PA7
};
static const uint8_t COL_PINS[8] = {
  PIN_PB0, PIN_PB1, PIN_PB2, PIN_PB3,
  PIN_PB4, PIN_PB5, PIN_PC0, PIN_PC1
};

static const uint8_t BTN_PIN = PIN_PC2;

// ---------- framebuffer ----------
// frame[col] = bitmask of which rows are lit when this column is on.
static volatile uint8_t frame[8];

// ---------- bird ----------
// y is in 1/8-pixel sub-units (8 sub-units = 1 LED row).
// vy is sub-units per game tick. Positive vy = falling (down).
static const uint8_t BIRD_X = 1;          // column the bird sits in
static int16_t bird_y  = 4 * 8;
static int16_t bird_vy = 0;
static const int16_t GRAVITY    = 1;      // sub-units / tick / tick
static const int16_t FLAP_VY    = -4;     // instant upward kick
static const int16_t MAX_FALL   = 4;      // terminal velocity

// ---------- pipes ----------
// Up to two pipes on screen at once. A pipe is its column position and
// the row of its gap (the gap is 3 rows tall: gap_y, gap_y+1, gap_y+2).
// "alive" means it's currently on screen; column < 0 -> off, dead.
struct Pipe {
  int8_t  x;          // column (-1 .. 7); below 0 means recycled
  int8_t  gap_y;      // top of the 3-row gap (0..5)
  bool    scored;     // has the bird already passed this one?
};
static const uint8_t MAX_PIPES = 2;
static Pipe pipes[MAX_PIPES];
static const uint8_t  GAP_HEIGHT  = 3;
static const uint8_t  PIPE_SPACING = 4;   // columns between new pipes

// ---------- score / mode ----------
static uint16_t score = 0;
static uint16_t best  = 0;

enum Mode : uint8_t {
  MODE_TITLE,    // animated bird, waiting for a tap
  MODE_PLAY,
  MODE_DEAD      // crash flash, then show score, then back to title
};
static uint8_t  mode = MODE_TITLE;
static uint32_t mode_started_ms = 0;

// ---------- timing ----------
static uint32_t last_tick_ms = 0;
static const uint16_t TICK_MS = 110;      // game tick rate (~9 Hz)

// Edge-detected button (falling edge = "just pressed").
static bool     btn_prev    = false;
static uint32_t last_btn_ms = 0;
static const uint16_t DEBOUNCE_MS = 20;

// ===================================================================
// LED MATRIX
// ===================================================================
//
// Same scheme as the Pong firmware: pins idle as INPUT (Hi-Z), and
// for each column we drive that column HIGH and pull lit rows LOW
// for a few hundred microseconds. Cycle through all 8 columns fast
// enough that the eye sees a steady image.

static void matrix_init() {
  for (uint8_t i = 0; i < 8; i++) {
    pinMode(ROW_PINS[i], INPUT);
    pinMode(COL_PINS[i], INPUT);
  }
  for (uint8_t i = 0; i < 8; i++) frame[i] = 0;
}

static void show_column(uint8_t c) {
  uint8_t mask = frame[c];

  for (uint8_t r = 0; r < 8; r++) {
    if (mask & (1 << r)) {
      pinMode(ROW_PINS[r], OUTPUT);
      digitalWrite(ROW_PINS[r], LOW);
    } else {
      pinMode(ROW_PINS[r], INPUT);
    }
  }

  pinMode(COL_PINS[c], OUTPUT);
  digitalWrite(COL_PINS[c], HIGH);
  delayMicroseconds(700);
  digitalWrite(COL_PINS[c], LOW);
  pinMode(COL_PINS[c], INPUT);

  for (uint8_t r = 0; r < 8; r++) {
    if (mask & (1 << r)) pinMode(ROW_PINS[r], INPUT);
  }
}

static void refresh_once() {
  for (uint8_t c = 0; c < 8; c++) show_column(c);
}

static inline void fb_clear() {
  for (uint8_t c = 0; c < 8; c++) frame[c] = 0;
}
static inline void fb_set(int8_t x, int8_t y) {
  if (x < 0 || x > 7 || y < 0 || y > 7) return;
  frame[x] |= (uint8_t)(1 << y);
}

// ===================================================================
// BUTTON
// ===================================================================
//
// One switch from the pin to GND, internal pull-up enabled.
// Pressed = LOW. We return TRUE only on the falling edge (just
// pressed this poll), not while held -- that way one tap = one flap.

static void button_init() {
  pinMode(BTN_PIN, INPUT_PULLUP);
}

static bool button_just_pressed() {
  uint32_t now = millis();
  bool pressed = (digitalRead(BTN_PIN) == LOW);
  bool edge = false;

  if (pressed != btn_prev) {
    if ((uint32_t)(now - last_btn_ms) >= DEBOUNCE_MS) {
      if (pressed && !btn_prev) edge = true;
      btn_prev    = pressed;
      last_btn_ms = now;
    }
  }
  return edge;
}

// ===================================================================
// GAME
// ===================================================================

static void spawn_pipe(uint8_t i, int8_t at_x) {
  pipes[i].x      = at_x;
  pipes[i].gap_y  = (int8_t)random(0, 8 - GAP_HEIGHT + 1);  // 0..5
  pipes[i].scored = false;
}

static void start_game() {
  bird_y  = 4 * 8;
  bird_vy = 0;
  score   = 0;

  // Two pipes, the first comfortably off to the right.
  spawn_pipe(0, 7);
  spawn_pipe(1, 7 + PIPE_SPACING);

  mode = MODE_PLAY;
  mode_started_ms = millis();
  last_tick_ms    = millis();
}

static void die() {
  if (score > best) best = score;
  mode = MODE_DEAD;
  mode_started_ms = millis();
}

// Returns true if (col, row) is part of a pipe wall.
static bool pipe_blocks(int8_t col, int8_t row) {
  for (uint8_t i = 0; i < MAX_PIPES; i++) {
    if (pipes[i].x == col) {
      // Inside the gap? Then it's clear.
      if (row >= pipes[i].gap_y && row < pipes[i].gap_y + GAP_HEIGHT) {
        return false;
      }
      return true;
    }
  }
  return false;
}

static void physics_tick() {
  // Bird.
  bird_vy += GRAVITY;
  if (bird_vy >  MAX_FALL) bird_vy =  MAX_FALL;
  if (bird_vy < -MAX_FALL) bird_vy = -MAX_FALL;
  bird_y += bird_vy;

  // Floor / ceiling = instant death.
  if (bird_y < 0)         { die(); bird_y = 0;     return; }
  if (bird_y > 7 * 8)     { die(); bird_y = 7 * 8; return; }

  // Scroll pipes left.
  for (uint8_t i = 0; i < MAX_PIPES; i++) {
    if (pipes[i].x >= -1) pipes[i].x--;
  }

  // Recycle any pipe that's gone off-screen, placing it after the
  // farthest-right surviving pipe.
  for (uint8_t i = 0; i < MAX_PIPES; i++) {
    if (pipes[i].x < 0) {
      int8_t furthest = 0;
      for (uint8_t j = 0; j < MAX_PIPES; j++) {
        if (j != i && pipes[j].x > furthest) furthest = pipes[j].x;
      }
      spawn_pipe(i, furthest + PIPE_SPACING);
    }
  }

  // Score: when a pipe's column moves past the bird, count it once.
  for (uint8_t i = 0; i < MAX_PIPES; i++) {
    if (!pipes[i].scored && pipes[i].x < BIRD_X) {
      pipes[i].scored = true;
      score++;
    }
  }

  // Collision: any pipe occupying the bird's column with the bird
  // outside the gap?
  int8_t br = bird_y / 8;
  if (pipe_blocks(BIRD_X, br)) die();
}

// ===================================================================
// RENDERING
// ===================================================================

static void draw_pipes() {
  for (uint8_t i = 0; i < MAX_PIPES; i++) {
    int8_t x = pipes[i].x;
    if (x < 0 || x > 7) continue;
    for (int8_t r = 0; r < 8; r++) {
      if (r < pipes[i].gap_y || r >= pipes[i].gap_y + GAP_HEIGHT) {
        fb_set(x, r);
      }
    }
  }
}

static void render_play() {
  fb_clear();
  draw_pipes();
  fb_set(BIRD_X, bird_y / 8);
}

// Title screen: bird gently bobs in place, "press to start".
static void render_title() {
  fb_clear();
  uint32_t t = millis() - mode_started_ms;
  // Slow sinusoidal-ish bob using a tiny lookup, no float math needed.
  static const int8_t bob[] = { 0, 0, 1, 1, 1, 0, 0, -1, -1, -1, 0, 0 };
  uint8_t phase = (t / 120) % (sizeof(bob) / sizeof(bob[0]));
  fb_set(BIRD_X, 3 + bob[phase]);

  // Decorative dots so the screen isn't dead.
  if (((t / 500) & 1) == 0) {
    fb_set(5, 1);
    fb_set(6, 6);
  }
}

// On crash: flash the whole screen a few times, then show the score
// as a vertical bar on the right side, then go back to title.
static void render_dead() {
  uint32_t t = millis() - mode_started_ms;
  fb_clear();

  if (t < 600) {
    // Three quick flashes.
    if (((t / 100) & 1) == 0) {
      for (uint8_t c = 0; c < 8; c++) frame[c] = 0xFF;
    }
    return;
  }

  if (t < 2400) {
    // Score bar: fill from the bottom up, capped at 8.
    uint8_t bars = score > 8 ? 8 : (uint8_t)score;
    for (uint8_t i = 0; i < bars; i++) fb_set(7, 7 - i);
    // Best-score marker on column 6.
    uint8_t bbars = best > 8 ? 8 : (uint8_t)best;
    if (bbars > 0) fb_set(6, 7 - (bbars - 1));
    return;
  }

  // Done -- back to title.
  mode = MODE_TITLE;
  mode_started_ms = millis();
}

// ===================================================================
// MAIN
// ===================================================================

void setup() {
  matrix_init();
  button_init();
  // Seed RNG off a floating ADC read so pipe gaps differ each power-up.
  analogReadResolution(10);
  randomSeed(analogRead(BTN_PIN) ^ micros());

  mode = MODE_TITLE;
  mode_started_ms = millis();
  last_tick_ms    = millis();
}

void loop() {
  uint32_t now = millis();
  bool tap = button_just_pressed();

  switch (mode) {
    case MODE_TITLE:
      if (tap) start_game();
      render_title();
      break;

    case MODE_PLAY:
      if (tap) bird_vy = FLAP_VY;
      if ((uint32_t)(now - last_tick_ms) >= TICK_MS) {
        last_tick_ms = now;
        physics_tick();
      }
      render_play();
      break;

    case MODE_DEAD:
      render_dead();
      // After the score display, a tap restarts immediately.
      if (tap && (now - mode_started_ms) > 600) start_game();
      break;
  }

  refresh_once();
}
